<script setup>
import AppNavbar from './components/layout/AppNavbar.vue';
</script>

<template>
  <AppNavbar />
  <router-view></router-view>
</template>

<style>
/* Global styles */
body { margin: 0; font-family: Arial, sans-serif; }
</style>