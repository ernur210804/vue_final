<template>
  <router-view />
</template>

<script setup>
// App.vue теперь — контейнер для страниц
</script>

<style>
body {
  margin: 0;
  font-family: Inter, system-ui, Avenir, Helvetica, Arial, sans-serif;
  background: #f5f6fa;
}
</style>
