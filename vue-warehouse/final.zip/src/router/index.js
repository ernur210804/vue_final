import { createRouter, createWebHistory } from 'vue-router'

const routes = [
  {
    path: '/',
    redirect: '/warehouses'
  },
  {
    path: '/warehouses',
    component: () => import('../pages/WarehousesPage.vue')
  },
  {
    path: '/:pathMatch(.*)*',
    component: {
      template: '<h2 style="padding:20px">404 — Page not found</h2>'
    }
  }
]

export default createRouter({
  history: createWebHistory(),
  routes
})
