<script setup>
</script>

<template>
  <div>404 - Page Not Found</div>
</template>

<style scoped>
div { padding: 20px; text-align: center; font-size: 24px; }
</style>