<template>
  <h1>404 - Page Not Found</h1>
</template>

<style scoped>
h1 {
  text-align: center;
  margin-top: 50px;
}
</style>
