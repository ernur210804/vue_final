<template>
  <div>
    <h1>Warehouse Accounting System</h1>
    <AnimatedBox />
  </div>
</template>

<script setup>
import AnimatedBox from '../components/AnimatedBox.vue'
</script>

<style scoped>
h1 {
  text-align: center;
}
</style>
