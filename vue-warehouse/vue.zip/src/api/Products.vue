<template>
  <Loader v-if="store.loading" />
  <ErrorMessage v-if="store.error" :text="store.error" />

  <ProductCard
    v-for="p in store.products"
    :key="p.id"
    :product="p"
    @select="go"
  />
</template>

<script setup>
import { onMounted } from 'vue'
import { useRouter } from 'vue-router'
import { useWarehouseStore } from '../store/warehouseStore'

const store = useWarehouseStore()
const router = useRouter()

onMounted(() => store.fetchProducts())
const go = (id) => router.push(`/products/${id}`)
</script>
